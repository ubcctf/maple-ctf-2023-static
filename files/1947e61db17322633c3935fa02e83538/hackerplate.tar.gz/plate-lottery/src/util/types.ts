export type PlayerMessage = {
    action: string,
    plate?: string,
    tickToStop?: string,
    vin?: string
}